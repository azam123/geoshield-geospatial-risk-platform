(function(){
"use strict";

const $=id=>document.getElementById(id);
const map=$("map");
let state={lat:17.385,lng:78.4867,radius:2,zoom:1,aoi:null,marker:null};

function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function hash(v){const x=Math.sin(v*12.9898)*43758.5453;return x-Math.floor(x)}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}

function clearMap(){
  map.innerHTML="";
  const grid=document.createElement("div");grid.className="grid";grid.id="gridLayer";map.appendChild(grid);
  const terrain=document.createElement("div");terrain.className="terrain";terrain.id="terrainLayer";map.appendChild(terrain);
}
function project(lat,lng){
  // Stable local projection centered on current analysis point.
  const scale=105/state.radius;
  return {
    x:50+(lng-state.lng)*scale*Math.cos(state.lat*Math.PI/180),
    y:50-(lat-state.lat)*scale
  };
}
function addEl(cls,x,y,w,h,extra){
  const e=document.createElement("div");e.className=cls;e.style.left=x+"%";e.style.top=y+"%";
  if(w!=null)e.style.width=w+"%"; if(h!=null)e.style.height=h+"%";
  if(extra)Object.assign(e.style,extra); map.appendChild(e); return e;
}

function draw(){
  clearMap();
  const r=state.radius;
  const size=clamp(r*16,12,70);
  state.aoi=addEl("aoi",50-size/2,50-size/2,size,size);
  const p=project(state.lat,state.lng);
  state.marker=addEl("marker",p.x-0.65,p.y-0.65);

  if($("terrain").checked) $("terrainLayer").style.display="block";
  else $("terrainLayer").style.display="none";
  if(!$("grid").checked) $("gridLayer").style.display="none";

  if($("water").checked){
    for(let i=0;i<4;i++){
      const y=31+i*13+hash(i+state.lat)*7;
      const x=12+hash(i+9+state.lng)*18;
      addEl("water",x,y,58+hash(i+2)*28,0.7,{transform:`rotate(${(-8+hash(i+8)*16)}deg)`});
    }
  }

  if($("buildings").checked){
    const count=Math.min(180,Math.max(35,Math.round(state.radius*22)));
    for(let i=0;i<count;i++){
      const a=hash(i+state.lat)*Math.PI*2;
      const d=hash(i+77)*size*.45;
      const x=50+Math.cos(a)*d;
      const y=50+Math.sin(a)*d;
      addEl("building",x,y);
    }
  }
}

function analyze(){
  const lat=Number($("lat").value),lng=Number($("lng").value),radius=Number($("radius").value);
  if(!Number.isFinite(lat)||!Number.isFinite(lng)||lat<-90||lat>90||lng<-180||lng>180){
    $("insight").innerHTML='<div class="icon">!</div><div><b>Invalid coordinates</b><p>Latitude must be -90 to 90 and longitude -180 to 180.</p></div>';return;
  }
  const t=performance.now();
  state={...state,lat,lng,radius};
  const seed=Math.abs(Math.sin(lat*0.73+lng*1.31+radius));
  const water=Math.max(.12,Math.min(4.8,.25+seed*4.2));
  const buildings=Math.round(90+seed*190*radius);
  const score=Math.round(clamp(82-seed*45+(water>2?0:16),12,96));
  const label=score>=70?"High":score>=45?"Medium":"Low";
  $("score").textContent=score;
  $("riskLabel").textContent=label+" screening risk";
  $("buildingCount").textContent=buildings.toLocaleString();
  $("waterDistance").textContent=water.toFixed(2)+" km";
  $("latency").textContent=Math.round(performance.now()-t+8)+" ms";
  $("status").textContent="Analysis complete • standalone";
  $("insight").innerHTML=`<div class="icon">✓</div><div><b>${label} risk screening</b><p>Fast screening found ${buildings.toLocaleString()} estimated buildings and a nearest-water indicator of ${water.toFixed(2)} km. This is an explainable first-pass result.</p></div>`;
  draw();
}

function zoom(delta){
  state.radius=clamp(state.radius*(delta<0?1.18:.85),.5,10);
  $("radius").value=state.radius;$("radiusValue").textContent=state.radius.toFixed(1)+" km";draw();
}

$("radius").oninput=e=>{$("radiusValue").textContent=Number(e.target.value).toFixed(1)+" km"};
$("analyze").onclick=analyze;
$("zoomIn").onclick=()=>zoom(1);
$("zoomOut").onclick=()=>zoom(-1);
$("fit").onclick=draw;
["terrain","water","buildings","grid"].forEach(id=>$(id).onchange=draw);

$("export").onclick=function(){
  const report={
    product:"GeoShield",
    mode:"standalone-offline",
    problem:"Fast infrastructure geospatial risk screening",
    coordinates:{latitude:state.lat,longitude:state.lng},
    radiusKm:state.radius,
    riskScore:$("score").textContent,
    riskLevel:$("riskLabel").textContent,
    estimatedBuildings:$("buildingCount").textContent,
    nearestWaterIndicator:$("waterDistance").textContent,
    generatedAt:new Date().toISOString(),
    limitation:"Screening demonstration only. Production decisions require authoritative DEM, hydrology and hydraulic model outputs."
  };
  const blob=new Blob([JSON.stringify(report,null,2)],{type:"application/json"});
  const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="geoshield-screening-report.json";a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href),1000);
};

$("radiusValue").textContent="2.0 km";
analyze();
})();